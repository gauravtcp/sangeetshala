import React, { useRef } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import Event from './components/Event';
import Testimonials from './components/Testimonials';
import Carousel from './components/Carousel';
import Services from './components/Services';
import About from './components/About';
import Gallery from './components/Gallery';
import Contacts from './components/Contacts';

const App = () => {
  const carouselRef = useRef(null);
  const servicesRef = useRef(null);
  const eventRef = useRef(null);
  const aboutRef = useRef(null);
  const galleryRef = useRef(null);
  const testimonialsRef = useRef(null);
  const contactsRef = useRef(null);

  const scrollToSection = (ref) => {
    if (ref.current) {
      ref.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div>
      <Header
        scrollToSection={scrollToSection}
        refs={{
          carouselRef,
          servicesRef,
          eventRef,
          aboutRef,
          galleryRef,
          testimonialsRef,
          contactsRef,
        }}
      />
      <div ref={carouselRef} >
        <Carousel scrollToSection={scrollToSection} contactsRef={contactsRef} />
      </div>
      <Services ref={servicesRef} />
      <Event ref={eventRef} />
      <About ref={aboutRef} />
      <Gallery ref={galleryRef} />
      <Testimonials ref={testimonialsRef} />
      <Contacts ref={contactsRef} />
      <Footer />
    </div>
  );
};

export default App;