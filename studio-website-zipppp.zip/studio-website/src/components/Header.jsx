import React, { useState } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemText
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import { useTheme, useMediaQuery } from '@mui/material';
import logo from '../assets/images/logo.png';

const Header = ({ scrollToSection, refs }) => {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const theme = useTheme();
  const isMobileOrTablet = useMediaQuery(theme.breakpoints.down('md'));

  const toggleDrawer = (open) => (event) => {
    if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
      return;
    }
    setDrawerOpen(open);
  };

  const navItems = [
    { label: 'Home', ref: refs.carouselRef },
    { label: 'Events', ref: refs.eventRef },
    { label: 'Gallery', ref: refs.galleryRef },
    { label: 'Contact', ref: refs.contactsRef },
  ];

  return (
    <AppBar
      position="fixed"
      sx={{
        backgroundColor: 'rgba(255, 255, 255, 0.8) !important;',
        color: 'black',
        borderRadius: '20px',
        width: '90%',
        margin: '10px auto',
        left: 0,
        right: 0,
        padding: '0 20px',
        boxShadow: 'none',
        zIndex: 10,
      }}
    >
      <Toolbar sx={{ justifyContent: 'space-between', alignItems: 'center' }}>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <img src={logo} alt="Sangeet Shala Studio" width="40" />
          <Typography variant="h6" sx={{ fontSize: { xs: '1rem' }, ml: 1, color: 'black' }}>
            Sangeet Shala Studio
          </Typography>
        </Box>

        {isMobileOrTablet ? (
          <>
            <IconButton
              edge="end"
              color="inherit"
              aria-label="menu"
              onClick={toggleDrawer(true)}
            >
              <MenuIcon />
            </IconButton>
            <Drawer
              anchor="right"
              open={drawerOpen}
              onClose={toggleDrawer(false)}
            >
              <Box
                sx={{ width: 250 }}
                role="presentation"
                onClick={toggleDrawer(false)}
                onKeyDown={toggleDrawer(false)}
              >
                <List>
                  {navItems.map(({ label, ref }) => (
                    <ListItem button key={label} onClick={() => scrollToSection(ref)}>
                      <ListItemText primary={label} />
                    </ListItem>
                  ))}
                  <ListItem>
                    <ListItemText primary="Student Login" />
                  </ListItem>
                </List>
              </Box>
            </Drawer>
          </>
        ) : (
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            {navItems.map(({ label, ref }) => (
              <Button
                key={label}
                color="inherit"
                sx={{
                  color: 'black',
                  mx: 1,
                  '&:hover': {
                    backgroundColor: 'rgba(0, 0, 0, 0.1)',
                  },
                }}
                onClick={() => scrollToSection(ref)}
              >
                {label}
              </Button>
            ))}
            <Button
              sx={{
                color: 'black',
                border: '1px solid black',
                borderRadius: 2,
                ml: 2,
                '&:hover': {
                  backgroundColor: 'rgba(0, 0, 0, 0.1)',
                },
              }}
            >
              Student Login
            </Button>
          </Box>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default Header;