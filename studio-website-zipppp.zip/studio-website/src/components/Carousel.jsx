import React, { useState, useEffect, forwardRef } from 'react';
import { Box, Typography, Button, IconButton } from '@mui/material';
import { ArrowBackIos, ArrowForwardIos } from '@mui/icons-material';
import image1 from '../assets/images/sangeetshala1.png'; 
import image2 from '../assets/images/sangeetshala2.png';
import image3 from '../assets/images/sangeetshala4.png';

const Carousel = ({scrollToSection, contactsRef }) => {
  const slides = [
    {
      image: image1,
      title: 'Welcome to Sangeet Shala',
      description: 'Unleash your musical talent with our experienced mentors.',
      buttonText: 'Learn More',
    },
    {
      image: image2,
      title: 'Join Our Classes',
      description: 'Master the art of music with personalized coaching.',
      buttonText: 'Sign Up',
    },
    {
      image: image3,
      title: 'Annual Concert',
      description: 'Showcase your skills at our prestigious events.',
      buttonText: 'Get Tickets',
    }
  ];

  const [currentSlide, setCurrentSlide] = useState(0);

  // Function to go to the next slide
  const nextSlide = () => {
    setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
  };

  // Function to go to the previous slide
  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
  };

  // Auto-slide every 5 seconds
  useEffect(() => {
    const slideInterval = setInterval(() => {
      setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
    }, 5000);
  
    return () => clearInterval(slideInterval);
  }); 

  return (
    <Box sx={{ position: 'relative', height: '100vh', overflow: 'hidden' }}>
      {slides.map((slide, index) => (
        <Box
          key={index}
          sx={{
            backgroundImage: `url(${slide.image})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            height: '100%',
            width: '100%',
            position: 'absolute',
            top: 0,
            left: index === currentSlide ? 0 : '100%',
            transition: 'left 0.5s ease',
            display: index === currentSlide ? 'flex' : 'none',
            justifyContent: 'center',
            alignItems: 'center',
            flexDirection: 'column',
          }}
        >
          <Box
            sx={{
              backgroundColor: 'rgba(0, 0, 0, 0.5)',
              color: '#fff',
              padding: '20px',
              borderRadius: '8px',
              textAlign: 'center',
              position: 'absolute',
              bottom: '60px',
            }}
          >
            <Typography variant="h4">{slide.title}</Typography>
            <Typography variant="body1" sx={{ mt: 1 }}>
              {slide.description}
            </Typography>
            <Button
              sx={{
                mt: 2,
                backgroundColor: 'white',
                color: 'black',
                '&:hover': {
                  backgroundColor: '#f5f5f5',
                },
              }}
              onClick={() => scrollToSection(contactsRef)}
            >
              {slide.buttonText}
            </Button>
          </Box>
        </Box>
      ))}

      <IconButton
        onClick={prevSlide}
        sx={{
          position: 'absolute',
          top: '50%',
          left: '20px',
          transform: 'translateY(-50%)',
          color: '#fff',
        }}
      >
        <ArrowBackIos />
      </IconButton>

      <IconButton
        onClick={nextSlide}
        sx={{
          position: 'absolute',
          top: '50%',
          right: '20px',
          transform: 'translateY(-50%)',
          color: '#fff',
        }}
      >
        <ArrowForwardIos />
      </IconButton>
    </Box>
  );
};

export default Carousel;