import React, { forwardRef } from 'react';
import { Box, Typography, Grid, Card, CardContent, Button } from '@mui/material';
import StarIcon from '@mui/icons-material/Star';

const testimonials = [
  {
    text: "Lorem ipsum dolor sit amet nulla vel, consectetur massa adipiscing.",
    name: "Jennifer J. Omalley",
  },
  {
    text: "Lorem ipsum dolor sit amet nulla vel, consectetur massa adipiscing.",
    name: "Christian T. Jackson",
  },
  {
    text: "Lorem ipsum dolor sit amet nulla vel, consectetur massa adipiscing.",
    name: "Connie L. Raymond",
  },
];

const Testimonials = forwardRef((props, ref) => {
  return (
    <Box
      ref={ref}
      sx={{
        padding: { xs: '30px 15px', md: '50px 0' },
        backgroundColor: '#f9f9f9',
        minHeight: '100vh',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      <Grid container justifyContent="center" sx={{ maxWidth: '100%', paddingX: { xs: 2, md: 4 } }}>
        <Grid item xs={12} textAlign="center" mb={4}>
          <Typography variant="h3" sx={{ fontWeight: 'bold', fontSize: { xs: '1.8rem', md: '2.5rem' }, marginBottom: 2 }}>
            Testimonials
          </Typography>
          <Typography variant="h5" sx={{ fontSize: { xs: '1rem', md: '1.25rem' }, marginBottom: 4 }}>
            Lorem ipsum dolor sit amet nulla vel, consectetur massa adipiscing.
          </Typography>
        </Grid>

        <Grid container spacing={{ xs: 4, md: 6 }} justifyContent="center">
          {testimonials.map((testimonial, index) => (
            <Grid item xs={12} sm={8} md={6} lg={4} key={index}>
              <Card
                sx={{
                  marginTop: 3, 
                  boxShadow: 3,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  textAlign: 'center',
                  padding: '8px', 
                  height: '100%',
                }}
              >
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'center', marginBottom: 2 }}>
                    {Array.from({ length: 5 }).map((_, i) => (
                      <StarIcon key={i} sx={{ color: 'green' }} />
                    ))}
                  </Box>
                  <Typography variant="body1" sx={{ marginBottom: 2, fontSize: { xs: '0.9rem', md: '1rem' } }}>
                    {testimonial.text}
                  </Typography>
                  <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                    {testimonial.name}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        <Grid container justifyContent="center" marginTop={7}>
          <Grid item>
            <Button variant="contained" color="primary" href="https://mobiri.se" sx={{ paddingX: 3 }}>
              Rate Us
            </Button>
          </Grid>
        </Grid>
      </Grid>
    </Box>
  );
});

export default Testimonials;