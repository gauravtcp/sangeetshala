import React, { forwardRef } from 'react';
import { Box, Typography, Grid, Card, CardContent, Link } from '@mui/material';

const Contacts = forwardRef((props, ref) => {
  return (
    <Box
      ref={ref} 
      sx={{
        padding: { xs: '30px 15px', md: '50px 0' },
        backgroundColor: '#f9f9f9',
      }}
    >
      <Grid
        container
        justifyContent="center"
        sx={{
          maxWidth: '100%',
          paddingX: { xs: 2, sm: 4, md: 6, lg: 8 }, 
        }}
      >
        <Grid item xs={12} textAlign="center" mb={5}>
          <Typography variant="h3" sx={{ fontWeight: 'bold', fontSize: { xs: '1.8rem', md: '2.5rem' } }}>
            Contacts
          </Typography>
        </Grid>

        <Grid container justifyContent="center" spacing={4}>
          <Grid item xs={12} md={6}>
            <Card
              sx={{
                boxShadow: 3,
                padding: '20px',
                display: 'flex',
                flexDirection: 'column',
              }}
            >
              <CardContent>
                <Typography variant="h5" sx={{ fontWeight: 'bold', marginBottom: 2 }}>
                  Contact Us
                </Typography>
                <ul style={{ padding: 0, listStyle: 'none' }}>
                  <li>
                    <Typography variant="body1">
                      Phone: <Link href="tel:+12345678910" color="primary">0 (800) 123 45 67</Link>
                    </Typography>
                  </li>
                  <li>
                    <Typography variant="body1">
                      WhatsApp: <Link href="tel:+12345678910" color="primary">0 (800) 123 45 67</Link>
                    </Typography>
                  </li>
                  <li>
                    <Typography variant="body1">
                      Email: <Link href="mailto:info@site.com" color="primary">info@site.com</Link>
                    </Typography>
                  </li>
                  <li>
                    <Typography variant="body1">
                      Address: 350 5th Ave, New York, NY 10118
                    </Typography>
                  </li>
                  <li>
                    <Typography variant="body1">
                      Working hours: 9:00AM - 6:00PM
                    </Typography>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} md={6}>
            <Box
              sx={{
                overflow: 'hidden',
                borderRadius: '8px',
                boxShadow: 3,
              }}
            >
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3668.3576655284437!2d75.78918007509614!3d23.157142679079662!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3963757e1a33c94d%3A0x33895898c11a2c86!2sSangeet%20Shala%20Studio!5e0!3m2!1sen!2sin!4v1730803956416!5m2!1sen!2sin"
                width="100%"
                height="350"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
              ></iframe>
            </Box>
          </Grid>
        </Grid>
      </Grid>
    </Box>
  );
});

export default Contacts;