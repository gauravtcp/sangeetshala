import React from 'react';
import { Container, Typography } from '@mui/material';

const Footer = () => {
  return (
    <Container maxWidth="lg" style={{ padding: '20px 0' }}>
      <Typography variant="body1" align="center">
        © Copyright 2025 Singing Institute - All Rights Reserved
      </Typography>
    </Container>
  );
};

export default Footer;