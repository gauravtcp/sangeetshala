import React from 'react';
import { Box, Typography, Grid } from '@mui/material';
import logo from '../assets/images/logo.png'; 

const About = () => {
  return (
    <Box
      sx={{
        padding: { xs: '20px 15px', md: '50px 0' },
        backgroundColor: '#f9f9f9',
      }}
    >
      <Grid container alignItems="center" justifyContent="center">
        <Grid item xs={12} md={6}>
          <img
            src={logo}
            alt="About Sangeet Shala Studio"
            style={{
              width: '80%', 
              height: 'auto',
              display: 'block',
              margin: '0 auto',
            }}
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <Box sx={{ padding: { xs: '0 10px', md: '0 20px' }, textAlign: 'left' }}>
            <Typography
              variant="h2"
              sx={{
                fontWeight: 'bold',
                fontSize: { xs: '1.8rem', md: '2.5rem' }, 
                marginBottom: '20px',
              }}
            >
              <strong>About Sangeet Shala Studio</strong>
            </Typography>
            <Typography
              variant="body1"
              sx={{
                fontSize: { xs: '1rem', md: '1.125rem' },
                marginBottom: '20px',
              }}
            >
              With a spirit of innovation, we navigate uncharted territories, exploring new ideas, technologies, and approaches. It is through our willingness to challenge conventions and think beyond boundaries that we discover innovative solutions that propel us forward.
            </Typography>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

export default About;