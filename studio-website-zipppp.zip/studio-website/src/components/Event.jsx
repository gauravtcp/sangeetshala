import React, { forwardRef } from 'react';
import { Box, Typography, Card, CardContent, Grid, Button } from '@mui/material';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';

const Event = forwardRef((props, ref) => {
  return (
    <Box
      ref={ref}
      sx={{
        width: '100%',
        backgroundColor: '#f9f9f9',
        padding: '50px 0',
      }}
    >
      <Typography
        variant="h2"
        sx={{
          fontWeight: 'bold',
          color: 'black',
          fontSize: { xs: '3rem', md: '4rem' },
          textAlign: 'center',
          marginBottom: '40px',
        }}
      >
        Our Events
      </Typography>

      <Grid container justifyContent="center">
        <Grid item xs={12} md={8}>
          <Card
            sx={{
              padding: '20px',
              boxShadow: 3,
              backgroundColor: '#fff',
              borderRadius: '15px',
            }}
          >
            <CardContent>
              <Typography variant="h5" sx={{ fontWeight: 'bold', mb: 3 }}>
                Poetry Masterclass
              </Typography>

              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <CalendarTodayIcon sx={{ color: 'green', marginRight: 1 }} />
                <Typography>November 25, 2023</Typography>
              </Box>

              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <AccessTimeIcon sx={{ color: 'green', marginRight: 1 }} />
                <Typography>2:00 PM - 4:00 PM</Typography>
              </Box>

              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <LocationOnIcon sx={{ color: 'green', marginRight: 1 }} />
                <Typography>5678 Avenue, Riseville, NY 56789</Typography>
              </Box>

              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <AttachMoneyIcon sx={{ color: 'green', marginRight: 1 }} />
                <Typography>$55, or included in our membership fee</Typography>
              </Box>

              <Typography variant="body1" sx={{ mb: 3 }}>
                Join poet Michael Smith for a Poetry Workshop suitable for poets of all levels. Whether you're new to poetry or experienced, Michael will help you improve your skills. Come connect with fellow poets and explore the world of poetry together.
              </Typography>

              <Button
                variant="contained"
                color="primary"
                sx={{ textTransform: 'none' }}
              >
                Learn more
              </Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
});

export default Event;