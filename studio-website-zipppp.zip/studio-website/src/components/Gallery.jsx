import React, { forwardRef } from 'react';
import { Grid, Modal, Box, IconButton, Typography } from '@mui/material';
import { styled } from '@mui/system';
import ZoomInIcon from '@mui/icons-material/ZoomIn';
import gallery01 from '../assets/images/gallery04.jpg';
import gallery02 from '../assets/images/gallery05.jpg';
import gallery03 from '../assets/images/gallery06.jpg';

const GalleryContainer = styled(Box)(({ theme }) => ({
  marginTop: theme.spacing(4),
  textAlign: 'center',
  padding: theme.spacing(2),
}));

const ImageWrapper = styled(Box)(({ theme }) => ({
  borderRadius: 16,
  overflow: 'hidden',
  cursor: 'pointer',
  position: 'relative',
  marginBottom: theme.spacing(2),
  '& img': {
    width: '100%',
    height: 'auto',
    objectFit: 'cover',
    borderRadius: 16,
  },
}));

const ModalImage = styled('img')({
  width: '100%',
  maxWidth: '80vw',
  maxHeight: '80vh',
  borderRadius: 16,
});

const IconButtonStyled = styled(IconButton)({
  position: 'absolute',
  top: '10px',
  right: '10px',
  color: '#fff',
});

const images = [
  gallery01,
  gallery02,
  gallery03,
];

const Gallery = forwardRef((props, ref) => {
  const [open, setOpen] = React.useState(false);
  const [selectedImage, setSelectedImage] = React.useState('');

  const handleOpen = (image) => {
    setSelectedImage(image);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setSelectedImage('');
  };

  return (
    <GalleryContainer ref={ref} >
      <Typography variant="h3" sx={{ fontWeight: 'bold', fontSize: { xs: '1.8rem', md: '2.5rem' }, mb: '1rem' }}>
        Gallery/Photos
      </Typography>
      <Grid container spacing={2} justifyContent="center">
        {images.map((image, index) => (
          <Grid item xs={6} sm={4} md={3} key={index}>
            <ImageWrapper onClick={() => handleOpen(image)}>
              <img src={image} alt={`Gallery ${index + 1}`} />
              <IconButtonStyled>
                <ZoomInIcon />
              </IconButtonStyled>
            </ImageWrapper>
          </Grid>
        ))}
      </Grid>

      <Modal open={open} onClose={handleClose}>
        <Box display="flex" justifyContent="center" alignItems="center" height="100vh" padding="10px">
          <ModalImage src={selectedImage} alt="Enlarged view" />
        </Box>
      </Modal>
    </GalleryContainer>
  );
});

export default Gallery;