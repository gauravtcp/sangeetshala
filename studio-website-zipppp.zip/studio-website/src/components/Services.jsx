import React from 'react';
import { Box, Typography, Card, CardContent, Grid } from '@mui/material';
import BuildIcon from '@mui/icons-material/Build';
import SchoolIcon from '@mui/icons-material/School';
import MusicNoteIcon from '@mui/icons-material/MusicNote';
import GroupIcon from '@mui/icons-material/Group';

const services = [
  {
    icon: <BuildIcon sx={{ color: 'green', marginRight: 1 }} />,
    title: 'Instrument Repair',
    description: 'Expert repair services for a wide variety of musical instruments.',
  },
  {
    icon: <SchoolIcon sx={{ color: 'green', marginRight: 1 }} />,
    title: 'Music Lessons',
    description: 'Learn to play your favorite instruments with our professional instructors.',
  },
  {
    icon: <MusicNoteIcon sx={{ color: 'green', marginRight: 1 }} />,
    title: 'Music Production',
    description: 'Record and produce your own music with our state-of-the-art equipment.',
  },
  {
    icon: <GroupIcon sx={{ color: 'green', marginRight: 1 }} />,
    title: 'Group Classes',
    description: 'Join group classes to learn and collaborate with fellow music enthusiasts.',
  },
];

const Services = () => {
  return (
    <Box
      sx={{
        width: '100%',
        backgroundColor: '#f9f9f9', 
        padding: '50px 0', 
      }}
    >
      <Typography
        variant="h2"
        sx={{
          fontWeight: 'bold',
          color: 'black',
          fontSize: { xs: '3rem', md: '4rem' }, 
          textAlign: 'center',
          marginBottom: '40px',
        }}
      >
        Our Services
      </Typography>

      <Grid container spacing={3} justifyContent="flex-start" padding={2}>
        {services.map((service, index) => (
          <Grid item xs={12} md={4} key={index}>
            <Card
              sx={{
                padding: '20px',
                boxShadow: 'none', 
                backgroundColor: '#fff',
                borderRadius: '15px',
                border: 'none', 
              }}
            >
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  {service.icon}
                  <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
                    {service.title}
                  </Typography>
                </Box>
                <Typography variant="body1">
                  {service.description}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default Services;